package veintenumerosenunarraydedimensionymuestreloselemtsqueocupposicionesimpares;

import java.util.Scanner;

public class Ejercicio55 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Scanner tc= new Scanner(System.in);
	
    int[] numeros = new int[20];

     // Llenar el arreglo con números aleatorios
     for (int i = 0; i < numeros.length; i++) {
      numeros[i] = (int)(Math.random() * 100);
		        }

      // Imprimir los elementos que ocupan posiciones impares
	  System.out.print("Elementos en posiciones impares: ");
       for (int i = 1; i < numeros.length; i += 2) {
      System.out.print(numeros[i] + " ");
		       
       }
		    
	 }

	
	}


