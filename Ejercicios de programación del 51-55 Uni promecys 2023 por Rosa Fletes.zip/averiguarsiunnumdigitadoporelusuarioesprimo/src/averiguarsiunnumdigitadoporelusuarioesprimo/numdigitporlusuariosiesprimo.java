package averiguarsiunnumdigitadoporelusuarioesprimo;

import java.util.Scanner;

public class numdigitporlusuariosiesprimo {

	    public static void main(String[] args) {
	       
	    	
	    	Scanner tc= new Scanner(System.in);

	        System.out.println("Ingrese el tamaño del arreglo: ");
	        int tamano = tc.nextInt();

	        int[] arreglo = new int[tamano];

	        // Llenar el arreglo con los números ingresados por el usuario
	        for (int i = 0; i < tamano; i++) {
	            System.out.print("Ingrese un número entero positivo: ");
	            arreglo[i] = tc.nextInt();
	        }

	        // Verificar si cada número del arreglo es primo o no
	        for (int i = 0; i < tamano; i++) {
	            boolean esPrimo = true;
	            for (int j = 2; j <= arreglo[i] / 2; j++) {
	                if (arreglo[i] % j == 0) {
	                    esPrimo = false;
	                    break;
	                }
	            }

	            if (esPrimo) {
	                System.out.println(arreglo[i] + " es primo");
	            } else {
	                System.out.println(arreglo[i] + " no es primo");
	            }
	        }
	    }
	}


