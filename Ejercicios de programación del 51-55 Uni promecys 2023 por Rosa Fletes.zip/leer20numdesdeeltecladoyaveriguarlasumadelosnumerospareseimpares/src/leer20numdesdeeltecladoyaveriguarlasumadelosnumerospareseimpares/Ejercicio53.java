package leer20numdesdeeltecladoyaveriguarlasumadelosnumerospareseimpares;

import java.util.Scanner;

public class Ejercicio53 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		        Scanner tc = new Scanner(System.in);

		        int[] numeros = new int[20];
		        int sumaPares = 0;
		        int sumaImpares = 0;

		        // Leer los 20 números ingresados por el usuario
		        for (int i = 0; i < numeros.length; i++) {
		            System.out.println("Ingrese un número entero: ");
		            numeros[i] = tc.nextInt();

		            if (numeros[i] % 2 == 0) {
		                sumaPares += numeros[i];
		            } else {
		                sumaImpares += numeros[i];
		            }
		        }

		        // Imprimir los resultados
		        System.out.println("La suma de los números pares es: " + sumaPares);
		        System.out.println("La suma de los números impares es: " + sumaImpares);
		

		
		
	}

}
