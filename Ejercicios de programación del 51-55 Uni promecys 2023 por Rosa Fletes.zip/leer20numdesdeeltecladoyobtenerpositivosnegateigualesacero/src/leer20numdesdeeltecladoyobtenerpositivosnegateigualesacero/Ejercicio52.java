package leer20numdesdeeltecladoyobtenerpositivosnegateigualesacero;

import java.util.Scanner;

public class Ejercicio52 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		        Scanner tc = new Scanner(System.in);

		        int[] numeros = new int[20];
		        int positivos = 0;
		        int negativos = 0;
		        int ceros = 0;

		        // Leer los 20 números ingresados por el usuario
		        for (int i = 0; i < numeros.length; i++) {
		            System.out.println("Ingrese un número entero: ");
		            numeros[i] = tc.nextInt();

		            if (numeros[i] > 0) {
		                positivos++;
		            } else if (numeros[i] < 0) {
		                negativos++;
		            } else {
		                ceros++;
		            }
		        }

		        // Imprimir los resultados
		        System.out.println("Cantidad de números positivos: " + positivos);
		        System.out.println("Cantidad de números negativos: " + negativos);
		        System.out.println("Cantidad de ceros: " + ceros);
		    }
		


	}
