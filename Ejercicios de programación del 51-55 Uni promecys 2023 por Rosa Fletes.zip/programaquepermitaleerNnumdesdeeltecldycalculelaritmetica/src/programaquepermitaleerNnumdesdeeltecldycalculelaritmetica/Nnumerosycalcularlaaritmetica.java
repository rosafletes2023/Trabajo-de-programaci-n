package programaquepermitaleerNnumdesdeeltecldycalculelaritmetica;

import java.util.Scanner;

public class Nnumerosycalcularlaaritmetica {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
	
	   System.out.println("Ingrese la cantidad de números a procesar: ");
	   int n = tc.nextInt();

		 int[] numeros = new int[n];
		 int suma = 0;

		        // Leer los n números ingresados por el usuario
	     for (int i = 0; i < numeros.length; i++) {
		 System.out.println("Ingrese el número " + (i+1) + ": ");
	     numeros[i] = tc.nextInt();
		 suma += numeros[i];
		   }

		 // Calcular la media aritmética
		 double media = (double)suma / n;

		        // Imprimir el resultado
	    System.out.println("La media aritmética es: " + media);
		
		
		
		
	}

}
