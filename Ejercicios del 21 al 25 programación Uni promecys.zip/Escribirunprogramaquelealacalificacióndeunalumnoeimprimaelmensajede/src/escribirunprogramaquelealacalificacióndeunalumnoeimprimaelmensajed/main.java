package escribirunprogramaquelealacalificacióndeunalumnoeimprimaelmensajed;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		int calificacion;
		
		System.out.println("Ingresa tu calificación");
		calificacion= tc.nextInt();
		
		if(calificacion>=60) {
			System.out.println("Aprobado");
			
	    }
	
		else {
			System.out.println("Reprobado");
		}
	
	}

}
