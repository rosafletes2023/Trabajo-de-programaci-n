package escribaunprogramaqueleaunnumeroA;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		int numero, y;
		
		System.out.println("Ingrese un número");
        numero = tc.nextInt();
        
        if (numero >= 0) {
            y = (int) Math.pow(2, numero);
        } else {
            y = numero + 5;
        }
        System.out.println("El resultado de Y es: " + y);
		
		
	}

}
