package escribaunprogramaqueleaunnúmeroyverifiquesixesnegativo;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		double x;
		double power4, power2;
		
		System.out.println("Ingrese un número: ");
        x = tc.nextDouble();

        if (x < 0) {
        power4 = Math.pow(x, 4);
        System.out.println("El número " + x + " elevado a la cuarta potencia es: " + power4);
        } 
        
        else {
        power2 = Math.pow(x, 2);
        
        System.out.println("El número " + x + " elevado a la segunda potencia es: " + power2);
       
        }
		
	}

}
