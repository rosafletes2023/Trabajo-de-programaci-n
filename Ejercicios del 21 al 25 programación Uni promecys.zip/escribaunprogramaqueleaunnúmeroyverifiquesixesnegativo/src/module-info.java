/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module escribaunprogramaqueleaunnúmeroyverifiquesixesnegativo {
}