package calcularelinterescapitalconformealacondicion;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		double capital,interes, tasa;
		System.out.println("Introduce el capital prestado");
		capital=tc.nextDouble();
		
		if(capital>10000) {
		   tasa= 0.07;
		}
		
		else {
			tasa= 0.06;
		
		}
		
		interes= capital*tasa;
		System.out.println("El interes es igual a: " +interes); 
		
	    
		
		
	}

}
