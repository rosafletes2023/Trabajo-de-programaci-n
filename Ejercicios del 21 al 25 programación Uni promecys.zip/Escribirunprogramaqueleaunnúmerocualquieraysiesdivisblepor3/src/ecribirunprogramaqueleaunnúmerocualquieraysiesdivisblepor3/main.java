package ecribirunprogramaqueleaunnúmerocualquieraysiesdivisblepor3;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		int numero;
		
		System.out.println("Ingresa un número");
		numero= tc.nextInt();
		
		if(numero%3==0)
		{
			System.out.println("El número: " +  numero + " es visible por tres");
			
		}
		
		else
		{
			System.out.println("El número: " +  numero + " no es divisible por tres");
		}
		
		
	}

}
