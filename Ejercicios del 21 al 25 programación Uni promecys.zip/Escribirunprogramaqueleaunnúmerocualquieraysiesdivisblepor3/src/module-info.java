/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module Escribirunprogramaqueleaunnúmerocualquieraysiesdivisblepor3 {
}