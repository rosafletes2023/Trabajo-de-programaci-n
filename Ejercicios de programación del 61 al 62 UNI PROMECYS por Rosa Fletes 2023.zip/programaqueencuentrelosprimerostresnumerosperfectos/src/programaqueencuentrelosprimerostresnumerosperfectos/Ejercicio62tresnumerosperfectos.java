package programaqueencuentrelosprimerostresnumerosperfectos;

public class Ejercicio62tresnumerosperfectos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		 int[] numerosPerfectos = new int[3];
	     int numero = 2;
		 int indice = 0;

		 while (indice < 3) {
         int sumaDivisores = 1;

		 for (int i = 2; i <= Math.sqrt(numero); i++) {
	     if (numero % i == 0) {
	     sumaDivisores += i;
		 if (i != numero / i) {
	     sumaDivisores += numero / i;
		  }
		  }
		  }

		  if (sumaDivisores == numero) {
          numerosPerfectos[indice] = numero;
	      indice++;
		  }

		   numero++;
		   }

		    System.out.println("Los primeros tres números perfectos son:");
		    for (int i = 0; i < numerosPerfectos.length; i++) {
		    System.out.println(numerosPerfectos[i]);
		   
		    }
		    
		 }
		
		
	 }