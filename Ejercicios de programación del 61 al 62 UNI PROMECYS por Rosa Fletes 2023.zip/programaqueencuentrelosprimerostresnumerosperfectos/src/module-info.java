/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module programaqueencuentrelosprimerostresnumerosperfectos {
}