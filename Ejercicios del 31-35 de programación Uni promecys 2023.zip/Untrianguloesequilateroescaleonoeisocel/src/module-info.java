/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module Untrianguloesequilateroescaleonoeisocel {
}