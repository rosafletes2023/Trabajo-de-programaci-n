package untrianguloesequilateroescaleonoeisocel;

import java.util.Scanner;

public class Clasificaciontriangulo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner (System.in);
		
		System.out.println("Ingrese las dimensiones del triángulo");
		
		int lado1= tc.nextInt();
		int lado2= tc.nextInt();
		int lado3= tc.nextInt();
		
		if(lado1==lado2 && lado2==lado3)
		{
			System.out.println("El triángulo es equilátero");
		}
		
		else if(lado1 == lado2 || lado1 == lado3 || lado2 == lado3)
		{
			System.out.println("El triángulo es isócel");
		}
		
		else
		{
			System.out.println("El triángulo es escaleno");
		}
		
	}
	

}
