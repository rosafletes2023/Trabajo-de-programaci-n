package numerosdel1al100;

public class numerosdel1al100 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i;
		
		for(i=0; i<=100; i++)
		{
			System.out.println(i+".");
		}
		
		
		
		
		
	}

}
