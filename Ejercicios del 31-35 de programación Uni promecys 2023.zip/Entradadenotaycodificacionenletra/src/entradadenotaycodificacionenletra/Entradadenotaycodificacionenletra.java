package entradadenotaycodificacionenletra;

import java.util.Scanner;

public class Entradadenotaycodificacionenletra {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Scanner tc= new Scanner(System.in);
		
		int calificacion;
		
		
		System.out.println("Ingresa tu calificación");
		calificacion= tc.nextInt();
		
		
		if(calificacion>=90)
		{
		  System.out.println("La calificación que obtuvo equivale a la letra A");
		}
		
		else if(calificacion>=80)
		
		{
			System.out.println("La calificación que obtuvo equivale a la letra B");
		}
		
		else if(calificacion>=70)
		{
			System.out.println("La calificación que obtuvo equivale a la letra C");
		}
		
		else if(calificacion>=65)
		{
			System.out.println("La calificación que obtuvo equivale a la letra D");
		
		}
		
		else
		{
			System.out.println("La calificación que obtuvo equivale a la letra E");
		}
	}

}
