package programaqueleatresnumeroscualquierasumarloypromediarlo;

import java.util.Scanner;

public class tresnumerossumarlosypromediarlos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		int num1, num2, num3;
		int sumaTotal;
		int promedio;
		
		System.out.println("Ingrese el primer número");
		num1= tc.nextInt();
		
		System.out.println("Ingrese el segundo número");
		num2= tc.nextInt();
		
		System.out.println("Ingrese el tercer número");
		num3= tc.nextInt();
		
		//Calcular la suma de los tres números
		sumaTotal= num1+num2+num3;
		
		//Calcular el promedio de los tres números
		promedio= sumaTotal/3;
		
		System.out.println("El resultado de la suma es : " + sumaTotal);
		System.out.println("El resultado del promedio es: " + promedio);
		
	}

}
