/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module programaqueleatresnumeroscualquierasumarloypromediarlo {
}