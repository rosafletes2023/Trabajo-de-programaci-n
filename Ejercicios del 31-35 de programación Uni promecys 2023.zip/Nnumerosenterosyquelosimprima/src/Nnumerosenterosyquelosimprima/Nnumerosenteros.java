package Nnumerosenterosyquelosimprima;

import java.util.Scanner;

public class Nnumerosenteros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		int n;
		int i;
		
		System.out.println("Introduzca un número entero");
		n= tc.nextInt();
		
		System.out.println("Números del 1 al " + n + ":");
		i=1;
		
		do {
	      System.out.println(i);
	      i++;
	        } while (i <= n);
		
		
		
		
		
	}

}
