/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module DeterminarlassolucionesdeNsistemadeecuacioneslineales {
}