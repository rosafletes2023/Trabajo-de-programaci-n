package determinarlassolucionesdeNsistemadeecuacioneslineales;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		double a, b, c, d, e, f;
		double x, y;
		double determinant;
		
	    System.out.println("Ingrese los coeficientes del sistema de ecuaciones lineales ax + by = c y dx + ey = f: ");
	    System.out.println("Ingrese el valor de a: ");
		a = tc.nextDouble();

		System.out.println("Ingrese el valor de b: ");
		b = tc.nextDouble();

	    System.out.println("Ingrese el valor de c: ");
		c = tc.nextDouble();

	    System.out.println("Ingrese el valor de d: ");
	    d = tc.nextDouble();

		System.out.println("Ingrese el valor de e: ");
	    e = tc.nextDouble();

	    System.out.println("Ingrese el valor de f: ");
		f = tc.nextDouble();

	    determinant = a * e - b * d;

	    if (determinant == 0) {
		 System.out.println("El sistema no tiene solución única.");
		} else {
		
		x = (c * e - b * f) / determinant;
		y = (a * f - c * d) / determinant;

	    System.out.println("Las soluciones del sistema son:");
	    System.out.println("x = " + x);
		System.out.println("y = " + y);
		      }

		
		
	}

}
