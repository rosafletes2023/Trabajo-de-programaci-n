/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module Escribaunprogramaquelealaedaddeunapersonaeimprimaesvotante {
}