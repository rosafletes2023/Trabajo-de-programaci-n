package escribaunprogramaquelealaedaddeunapersonaeimprimaesvotante;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		int edad;
		
		System.out.println("Ingresa tu edad");
		edad= tc.nextInt();
	
		if( edad>=16) {
		System.out.println("Usted es votante");
		
		}
		
		else {
			System.out.println("No eres votante");
		}
	}

}
