/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module Determinarlaenergiatotalquealamacenauncerpo {
}