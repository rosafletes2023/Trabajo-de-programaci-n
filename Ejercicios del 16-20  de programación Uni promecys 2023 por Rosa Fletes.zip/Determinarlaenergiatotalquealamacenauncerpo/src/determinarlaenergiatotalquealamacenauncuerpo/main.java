package determinarlaenergiatotalquealamacenauncuerpo;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner tc= new Scanner(System.in);
		
        double m, v, h;
		
		System.out.println("Ingrese la masa del cuerpo en kg: ");
        m = tc.nextDouble();

        System.out.println("Ingrese la velocidad del cuerpo en m/s: ");
        v = tc.nextDouble();

        System.out.println("Ingrese la altura del cuerpo en metros: ");
        h = tc.nextDouble();

        final double g = 9.81; // Constante de gravedad en m/s^2

        double kineticEnergy = 0.5 * m * Math.pow(v, 2);
        double potentialEnergy = m * h * g;
        double totalEnergy = kineticEnergy + potentialEnergy;

        System.out.println("La energía cinética del cuerpo es: " + kineticEnergy + " J");
        System.out.println("La energía potencial del cuerpo es: " + potentialEnergy + " J");
        System.out.println("La energía total almacenada en el cuerpo es: " + totalEnergy + " J");
   
	}






	}


