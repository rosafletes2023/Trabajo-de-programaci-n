package leerunnumerodetrescifraseimprimirloenordeninvertido;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
	
		int number;
		int digito1, digito2, digito3;
		
		System.out.println("Ingrese un número de 3 cifras");
	    number= tc.nextInt();
	    
	    digito1= number / 100; // Primer dígito
        digito2 = (number / 10) % 10; // Segundo dígito
        digito3 = number % 10; // Tercer dígito
        
        System.out.println("El número invertido es :" +digito3 + digito2 + digito1);
		
		
		
		
	}

}
