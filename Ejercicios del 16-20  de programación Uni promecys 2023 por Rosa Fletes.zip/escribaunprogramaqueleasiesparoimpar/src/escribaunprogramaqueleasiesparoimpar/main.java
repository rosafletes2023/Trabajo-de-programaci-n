package escribaunprogramaqueleasiesparoimpar;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		int numero;
		
		System.out.println("Introduzca un número entero");
		numero= tc.nextInt();
		
		if(numero%2==0) {
			System.out.println("EL número es par");
		}
		
		else {
			System.out.println("Es impar");
		
		}
		
		
	}

}
