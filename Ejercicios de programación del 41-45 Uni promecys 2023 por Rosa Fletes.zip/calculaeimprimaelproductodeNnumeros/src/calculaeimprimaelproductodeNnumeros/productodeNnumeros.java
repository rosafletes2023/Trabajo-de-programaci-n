package calculaeimprimaelproductodeNnumeros;

import java.util.Scanner;

public class productodeNnumeros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		 int n;
	     System.out.println("Ingrese el número de números a multiplicar: ");
	     n = tc.nextInt();
	        
	     int producto = 1;
	        
	     for (int i = 1; i <= n; i++) {
	     int numero;
	     System.out.printf("Ingrese el número %d: ", i);
	     numero = tc.nextInt();
	           
	     producto *= numero;
	        }
	        
	     System.out.printf("El producto de los %d números ingresados es %d", n, producto);
	     
	     
	    }
	

}
