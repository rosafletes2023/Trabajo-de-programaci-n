package voltajeminimovsmaximoypromedio;

import java.util.Scanner;

public class programadevoltajeminimvsmaximoypromedio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
	      int n;
	      double suma = 0, minimo = Double.MAX_VALUE, maximo = Double.MIN_VALUE;

		
		
		System.out.println("Ingresa el número de voltajes a ingresar: ");
	      n = tc.nextInt();

	      for (int i = 0; i < n; i++) {
	         System.out.println("Ingresa el voltaje " + (i+1) + ": ");
	         double voltaje = tc.nextDouble();
	         suma += voltaje;
	         if (voltaje < minimo) {
	            minimo = voltaje;
	         }
	         if (voltaje > maximo) {
	            maximo = voltaje;
	         }
	      }

	      double promedio = suma / n;

	      System.out.println("El voltaje mínimo es: " + minimo);
	      System.out.println("El voltaje máximo es: " + maximo);
	      System.out.println("El promedio de los voltajes es: " + promedio);
	   

		
		
	}

}
