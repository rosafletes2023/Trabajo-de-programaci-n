/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module voltajeminimovsmaximoypromedio {
}