package enuncursode25alumnossepractican3exams;

import java.util.Scanner;

public class veinticincoalumnospractiantresexamenes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
         final int NUMERO_ALUMNOS = 25;
        
        for (int i = 0; i < NUMERO_ALUMNOS; i++) {
        System.out.println("Ingrese el nombre del alumno " + (i+1) + ": ");
        String nombre = tc.next();
            
        System.out.println("Ingrese la nota 1 del alumno " + (i+1) + ": ");
        double nota1 = tc.nextDouble();
            
        System.out.println("Ingrese la nota 2 del alumno " + (i+1) + ": ");
        double nota2 = tc.nextDouble();
            
         System.out.println("Ingrese la nota 3 del alumno " + (i+1) + ": ");
         double nota3 = tc.nextDouble();
            
         double promedio = (nota1 + nota2 + nota3) / 3;
         System.out.println("El promedio de notas de " + nombre + " es " + promedio);
		
        }
		
		
	}

}
