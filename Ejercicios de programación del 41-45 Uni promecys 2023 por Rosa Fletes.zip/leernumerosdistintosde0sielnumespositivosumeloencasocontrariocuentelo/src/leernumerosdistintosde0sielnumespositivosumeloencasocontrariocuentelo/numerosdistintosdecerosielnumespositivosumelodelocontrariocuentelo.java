package leernumerosdistintosde0sielnumespositivosumeloencasocontrariocuentelo;

import java.util.Scanner;

public class numerosdistintosdecerosielnumespositivosumelodelocontrariocuentelo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	      Scanner tc = new Scanner(System.in);
	      int n, sumaPositivos = 0, conteoNegativos = 0;

	      System.out.println("Ingresa el valor de N: ");
	      n = tc.nextInt();

	      for (int i = 0; i < n; i++) {
	         System.out.print("Ingresa el número " + (i+1) + ": ");
	         int numero = tc.nextInt();
	         if (numero > 0) {
	            sumaPositivos += numero;
	         } else if (numero < 0) {
	            conteoNegativos++;
	         }
	      }

	      System.out.println("La suma de los números positivos ingresados es: " + sumaPositivos);
	      System.out.println("El número de números negativos ingresados es: " + conteoNegativos);
	   }

		
}
