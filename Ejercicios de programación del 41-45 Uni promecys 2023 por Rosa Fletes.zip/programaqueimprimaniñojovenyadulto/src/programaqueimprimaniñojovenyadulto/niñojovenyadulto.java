package programaqueimprimaniñojovenyadulto;

import java.util.Scanner;

public class niñojovenyadulto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		System.out.println("Ingrese la edad: ");
        int edad = tc.nextInt();
        
        if (edad < 13) 
        {
            System.out.println("niño");
        } 
        else if (edad <= 25) {
            System.out.println("joven");
        } 
        else {
            System.out.println("adulto");

		
        }
	}

}
