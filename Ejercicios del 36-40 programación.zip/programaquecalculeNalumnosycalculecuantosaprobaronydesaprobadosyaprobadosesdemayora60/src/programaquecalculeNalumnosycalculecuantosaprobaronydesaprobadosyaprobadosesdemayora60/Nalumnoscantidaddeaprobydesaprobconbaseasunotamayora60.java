package programaquecalculeNalumnosycalculecuantosaprobaronydesaprobadosyaprobadosesdemayora60;

import java.util.Scanner;

public class Nalumnoscantidaddeaprobydesaprobconbaseasunotamayora60 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try (Scanner tc = new Scanner (System.in)) {
			int n;
			
			System.out.print("Ingrese el número de alumnos: ");
			n = tc.nextInt();
			
			int aprobados = 0;
			int desaprobados = 0;
			
			for (int i = 1; i <= n; i++) {
			int nota;
			System.out.printf("Ingrese la nota del alumno %d: ", i);
			nota = tc.nextInt();
			    
			if (nota >= 60) {
			aprobados++;
			} 
			else {
			desaprobados++;
			
			System.out.print(aprobados);
			System.out.printf("Número de desaprobados: %d\n", desaprobados);
			
			
			
			
			
			     }
			}
		}
	}

}
