/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module programaquecalculeNalumnosycalculecuantosaprobaronydesaprobadosyaprobadosesdemayora60 {
}