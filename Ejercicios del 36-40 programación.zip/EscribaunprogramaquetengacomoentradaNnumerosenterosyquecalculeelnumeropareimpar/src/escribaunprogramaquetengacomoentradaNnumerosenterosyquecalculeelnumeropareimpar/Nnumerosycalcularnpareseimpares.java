package escribaunprogramaquetengacomoentradaNnumerosenterosyquecalculeelnumeropareimpar;

import java.util.Scanner;

public class Nnumerosycalcularnpareseimpares {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc = new Scanner(System.in);
			
		System.out.println("Ingresa el número de enteros a evaluar: ");
        int n = tc.nextInt();
        
        int pares = 0;
        int impares = 0;
        
        System.out.println("Ingresa los " + n + " números enteros:");
        
        for(int i = 1; i <= n; i++) {
            int num = tc.nextInt();
            
            if(num % 2 == 0) {
                pares++;
            } else {
                impares++;
            }
        }
        
        System.out.println("Número de pares: " + pares);
        System.out.println("Número de impares: " + impares);

             
		
		
          }
	}


