/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module EscribaunprogramaquetengacomoentradaNnumerosenterosyquecalculeelnumeropareimpar {
}