package programadeNnumerosquecalculelasumaypromedio;

import java.util.Scanner;

public class Nnumerosquecalculelasumaypromedio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try (Scanner sc = new Scanner(System.in)) {
			int n;
			int suma=0;
			double promedio;
			int i;
			
			System.out.println("Ingrese la cantidad de números a sumar");
			n= sc.nextInt();
			
			for(i=1; i<=n; i++) {
			System.out.println("Ingrese el número " +  i + ":" );
			int num= sc.nextInt();
			suma+=num;
			}
			
			promedio = (double) suma / n;

			System.out.println("La suma de los numeros es: " + suma);
			System.out.println("El promedio de los numeros es: " + promedio);
		}
		
	}

}
