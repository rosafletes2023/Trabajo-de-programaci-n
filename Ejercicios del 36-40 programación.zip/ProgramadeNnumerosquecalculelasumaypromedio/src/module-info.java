/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module ProgramadeNnumerosquecalculelasumaypromedio {
}