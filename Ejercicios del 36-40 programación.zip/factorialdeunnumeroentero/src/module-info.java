/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module factorialdeunnumeroentero {
}