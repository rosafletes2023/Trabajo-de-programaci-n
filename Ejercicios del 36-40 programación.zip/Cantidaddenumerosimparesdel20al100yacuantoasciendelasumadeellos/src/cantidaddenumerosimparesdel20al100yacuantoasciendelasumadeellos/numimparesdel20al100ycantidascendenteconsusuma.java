package cantidaddenumerosimparesdel20al100yacuantoasciendelasumadeellos;

public class numimparesdel20al100ycantidascendenteconsusuma {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int suma = 0;
        int impares = 0;

        for (int i = 20; i <= 100; i++) {
            if (i % 2 != 0) {
                impares++;
                suma += i;
            }
        }

        System.out.println("La cantidad de numeros impares es: " + impares);
        System.out.println("La suma de los numeros impares es: " + suma);

		
		
		
		
	}

}
