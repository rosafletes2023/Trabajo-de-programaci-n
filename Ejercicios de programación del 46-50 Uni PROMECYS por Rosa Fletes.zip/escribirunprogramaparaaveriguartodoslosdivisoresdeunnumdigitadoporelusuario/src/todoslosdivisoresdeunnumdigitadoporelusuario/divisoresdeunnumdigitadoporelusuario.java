package todoslosdivisoresdeunnumdigitadoporelusuario;

import java.util.Scanner;

public class divisoresdeunnumdigitadoporelusuario {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		

		        Scanner tc = new Scanner(System.in);
		        
		        
		        System.out.println("Ingrese un número entero positivo: ");
		        int num = tc.nextInt();
		        int[] divisores = new int[num];
		        int contador = 0;

		        for (int i = 1; i <= num; i++) {
		            if (num % i == 0) {
		                divisores[contador] = i;
		                contador++;
		            }
		        }

		        System.out.println("Los divisores de " + num + " son:");
		        for (int i = 0; i < contador; i++) {
		            System.out.println(divisores[i]);
		        }
		  
		
	}

}
