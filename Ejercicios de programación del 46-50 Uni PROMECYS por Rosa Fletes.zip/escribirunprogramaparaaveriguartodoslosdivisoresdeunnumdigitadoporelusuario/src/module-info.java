/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module escribirunprogramaparaaveriguartodoslosdivisoresdeunnumdigitadoporelusuario {
}