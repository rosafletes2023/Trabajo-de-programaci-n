package dadoaunarreglolinealdeNelementosescribaunprogramaporcadainciso;

import java.util.Scanner;

public class programaparacadainciso {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		        Scanner tc = new Scanner(System.in);

		        System.out.println("Ingresa la cantidad de elementos en el arreglo: ");
		        int n = tc.nextInt();

		        int[] arreglo = new int[n];

		        System.out.println("Ingresa los elementos del arreglo:");

		        for (int i = 0; i < n; i++) {
		            arreglo[i] = tc.nextInt();
		        }

		        System.out.println("Selecciona una opción:");
		        System.out.println("a) La suma de sus elementos.");
		        System.out.println("b) La suma de sus elementos elevados al cuadrado.");
		        System.out.println("c) El menor elemento y la posición del mismo dentro del arreglo.");
		        System.out.println("d) El mayor elemento y la posición del mismo dentro del arreglo.");
		        System.out.println("e) El promedio de los elementos.");
		        System.out.println("f) Ordénalos de forma ascendente.");
		        System.out.println("g) Calcular el módulo del arreglo.");
		        char opcion = tc.next().charAt(0);

		        switch (opcion) {
		            case 'a':
		                int suma = 0;
		                for (int i = 0; i < n; i++) {
		                    suma += arreglo[i];
		                }
		                System.out.println("La suma de los elementos es: " + suma);
		                break;
		                
		            case 'b':
		                int sumaCuadrados = 0;
		                for (int i = 0; i < n; i++) {
		                    sumaCuadrados += arreglo[i] * arreglo[i];
		                }
		                System.out.println("La suma de los elementos elevados al cuadrado es: " + sumaCuadrados);
		                break;
		            case 'c':
		                int menor = arreglo[0];
		                int posicionMenor = 0;
		                for (int i = 1; i < n; i++) {
		                    if (arreglo[i] < menor) {
		                        menor = arreglo[i];
		                        posicionMenor = i;
		                    }
		                }
		                
		                System.out.println("El menor elemento es: " + menor + " y se encuentra en la posición " + posicionMenor);
		                break;
		            case 'd':
		                int mayor = arreglo[0];
		                int posicionMayor = 0;
		                for (int i = 1; i < n; i++) {
		                    if (arreglo[i] > mayor) {
		                        mayor = arreglo[i];
		                        posicionMayor = i;
		                    }
		                }
		                
		                System.out.println("El mayor elemento es: " + mayor + " y se encuentra en la posición " + posicionMayor);
		                break;
		                
		                
		            case 'e':
		                double promedio = 0;
		                for (int i = 0; i < n; i++) {
		                    promedio += arreglo[i];
		                }
		                promedio /= n;
		                System.out.println("El promedio de los elementos es: " + promedio);
		                break;
		                
		            case 'f':
		                for (int i = 0; i < n - 1; i++) {
		                    for (int j = i + 1; j < n; j++) {
		                        if (arreglo[i] > arreglo[j]) {
		                            int auxiliar = arreglo[i];
		                            arreglo[i] = arreglo[j];
		                            arreglo[j] = auxiliar;
		                        }
		                    }
		                }
		                System.out.println("El arreglo ordenado de forma ascendente es:");
		                for (int i = 0; i < n; i++) {
		                    System.out.println(arreglo);
		                    
		                }


                
            case 'g':
                int modulo = 0;
                for (int i = 0; i < n; i++) {
                    modulo += Math.abs(arreglo[i]);
                }
                System.out.println("El módulo del arreglo es: " + modulo);
                break;
            default:
                System.out.println("Opción no válida.");
                break;
                
                
                
                
                
		 
    
             }        
                       
		
	}

}
