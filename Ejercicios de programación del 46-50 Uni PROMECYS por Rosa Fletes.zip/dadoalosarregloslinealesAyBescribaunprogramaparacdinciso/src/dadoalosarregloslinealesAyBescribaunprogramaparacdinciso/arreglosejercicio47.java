package dadoalosarregloslinealesAyBescribaunprogramaparacdinciso;

import java.util.Scanner;

public class arreglosejercicio47 {

public static void main(String[] args) {
	
    Scanner tc = new Scanner(System.in);
    int n;
    double[] a, b;
    double productoPunto = 0.0, moduloA = 1.0, moduloB = 1.0, z = 0.0;
    boolean sonOrtogonales = true;
    
    System.out.println("Ingrese el tamaño de los arreglos: ");
    n = tc.nextInt();
    
    a = new double[n];
    b = new double[n];
    
    System.out.println("Ingrese los elementos del arreglo A:");
    for(int i = 0; i < n; i++) {
        a[i] = tc.nextDouble();
    }
    
    System.out.println("Ingrese los elementos del arreglo B:");
    for(int i = 0; i < n; i++) {
        b[i] = tc.nextDouble();
    }
    
    System.out.println("Seleccione una opción:");
    System.out.println("1. Producto de puntos");
    System.out.println("2. Determinar si son ortogonales");
    System.out.println("3. Obtener la expresión Z");
    
    int opcion = tc.nextInt();
    
    switch(opcion) {
        case 1:
            for(int i = 0; i < n; i++) {
                productoPunto += a[i] * b[i];
            }
            System.out.println("El producto de puntos es: " + productoPunto);
            break;
        case 2:
            for(int i = 0; i < n; i++) {
                if(a[i] * b[i] != 0) {
                    sonOrtogonales = false;
                    break;
                }
            }
            if(sonOrtogonales) {
                System.out.println("Los arreglos son ortogonales.");
            } else {
                System.out.println("Los arreglos no son ortogonales.");
            }
            break;
        case 3:
            for(int i = 0; i < n; i++) {
                moduloA *= a[i];
                moduloB *= b[i];
                z += a[i] * b[i];
            }
            z /= (moduloA * moduloB);
            System.out.println("La expresión Z es: " + z);
            break;
        default:
            System.out.println("Opción inválida.");
            break;
    }

	
	
	
	
	
	
	
	
	
	
	
	
	
	
     }	
}