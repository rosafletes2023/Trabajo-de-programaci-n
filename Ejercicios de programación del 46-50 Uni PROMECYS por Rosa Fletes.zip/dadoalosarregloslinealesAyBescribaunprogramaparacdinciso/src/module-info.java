/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module dadoalosarregloslinealesAyBescribaunprogramaparacdinciso {
}