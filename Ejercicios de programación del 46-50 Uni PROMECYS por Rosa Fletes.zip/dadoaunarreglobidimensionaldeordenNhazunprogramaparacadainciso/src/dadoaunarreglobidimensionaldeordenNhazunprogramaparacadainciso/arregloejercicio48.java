package dadoaunarreglobidimensionaldeordenNhazunprogramaparacadainciso;

import java.util.Scanner;

public class arregloejercicio48 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		        Scanner tc = new Scanner(System.in);

		        System.out.println("Ingresa el valor de N: ");
		        int n = tc.nextInt();

		        int[][] matriz = new int[n][n];

		        System.out.println("Ingresa los elementos de la matriz:");

		        for (int i = 0; i < n; i++) {
		            for (int j = 0; j < n; j++) {
		                matriz[i][j] = tc.nextInt();
		            }
		        }

		        System.out.println("Selecciona una opción:");
		        System.out.println("a) Leer la matriz y mostrarla en el orden dado.");
		        System.out.println("b) Mostrar los elementos que están sobre la diagonal principal.");
		        System.out.println("c) Mostrar los elementos que están encima de la diagonal principal.");
		        System.out.println("d) Mostrar los elementos que están por debajo y sobre la diagonal principal.");
		        char opcion = tc.next().charAt(0);

		        switch (opcion) {
		            case 'a':
		                System.out.println("La matriz es:");
		                for (int i = 0; i < n; i++) {
		                    for (int j = 0; j < n; j++) {
		                        System.out.print(matriz[i][j] + " ");
		                    }
		                    System.out.println();
		                }
		                break;
		            case 'b':
		                System.out.println("Los elementos sobre la diagonal principal son:");
		                for (int i = 0; i < n; i++) {
		                    for (int j = i + 1; j < n; j++) {
		                        System.out.print(matriz[i][j] + " ");
		                    }
		                }
		                System.out.println();
		                break;
		            case 'c':
		                System.out.println("Los elementos encima de la diagonal principal son:");
		                for (int i = 0; i < n; i++) {
		                    for (int j = 0; j < i; j++) {
		                        System.out.print(matriz[i][j] + " ");
		                    }
		                }
		                System.out.println();
		                break;
		            case 'd':
		                System.out.println("Los elementos por debajo y sobre la diagonal principal son:");
		                for (int i = 0; i < n; i++) {
		                    for (int j = 0; j < n; j++) {
		                        if (i > j) {
		                            System.out.print(matriz[i][j] + " ");
		                        } else if (i < j) {
		                            System.out.print(matriz[i][j] + " ");
		                        }
		                    }
		                }
		                System.out.println();
		                break;
		            default:
		                System.out.println("Opción no válida.");
		                break;
		       
		}

		
		
		
	}

}
