package dadolosarreglosbidimencionalesescribaunprogramaquedescribacadainciso;

public class Arreglosejercicio49 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		        int[][] A = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
		        int[][] B = {{9, 8, 7}, {6, 5, 4}, {3, 2, 1}};
		        int[][] resultado;
		        int opcion = 1; // cambia este valor para seleccionar la operación a realizar
		        
		        switch (opcion) {
		            case 1:
		                // Suma de A y B
		                resultado = new int[A.length][A[0].length];
		                for (int i = 0; i < A.length; i++) {
		                    for (int j = 0; j < A[0].length; j++) {
		                        resultado[i][j] = A[i][j] + B[i][j];
		                    }
		                }
		                System.out.println("La suma de A y B es:");
		                for (int i = 0; i < resultado.length; i++) {
		                    for (int j = 0; j < resultado[0].length; j++) {
		                        System.out.print(resultado[i][j] + " ");
		                    }
		                    System.out.println();
		                }
		                break;
		                
		                
		            case 2:
		                // Suma de la segunda fila de A y la tercera fila de B
		                resultado = new int[1][A[0].length];
		                for (int j = 0; j < A[0].length; j++) {
		                    resultado[0][j] = A[1][j] + B[2][j];
		                }
		                System.out.println("La suma de la segunda fila de A y la tercera fila de B es:");
		                for (int i = 0; i < resultado.length; i++) {
		                    for (int j = 0; j < resultado[0].length; j++) {
		                        System.out.print(resultado[i][j] + " ");
		                    }
		                    System.out.println();
		                }
		                break;
		                
		            default:
		                System.out.println("Opción inválida");
		        
		    }
		
		
		
		
	}

}
