package convertirnkilogramosalibras;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		double kilos;
		double libras;
		
		System.out.println("Ingresa la cantidad de kilogramos");
		kilos=tc.nextDouble();
		
		libras= 2*2.20462;
		
		System.out.println(kilos + " kilogramos equivale a " + libras + " libras.");
		
	}

}
