package determineelvalordelafuerzadeuncuerpoquetienepormasaMyaceleraciónA;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		double masa, aceleración;
		double fuerza;
		
		System.out.println("Ingresa la masa del cuerpo en kg");
		masa= tc.nextDouble();
		
		System.out.println("Ingresa la aceleración del cuerpo en m/s^2");
		aceleración= tc.nextDouble();
		
		// Calcula el valor de la fuerza utilizando la fórmula F = ma
        fuerza = masa * aceleración;
        
        System.out.println("El valor de la fuerza es: " + fuerza + " N");
		
		
		
	}

}
