/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module calcularelareadeuntrianguloconociendosustreslados {
}