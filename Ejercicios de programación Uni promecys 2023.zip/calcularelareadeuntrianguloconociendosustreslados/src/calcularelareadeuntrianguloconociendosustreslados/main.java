package calcularelareadeuntrianguloconociendosustreslados;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		double lado1, lado2, lado3;
		double semiperimetro;
		double area;
		
		System.out.println("Ingresa el primer lado del triángulo");
		lado1= tc.nextDouble();
		
		System.out.println("Ingresa el segundo lado del triángulo");
		lado2= tc.nextDouble();
		
		System.out.println("Ingresa el tercer lado del triángulo");
		lado3= tc.nextDouble();
		
		// Calcula el semiperímetro del triángulo
        semiperimetro = (lado1 + lado2 + lado3) / 2;
        
     // Calcula el área del triángulo utilizando la fórmula de Herón
        area = Math.sqrt(semiperimetro * (semiperimetro - lado1) * (semiperimetro - lado2) * (semiperimetro - lado3));
        
        System.out.println("El área del triángulo es: " + area);
    

		
	}

}
