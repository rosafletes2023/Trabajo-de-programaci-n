package convertirxgradosfahrenheitagradoscelsius;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		double fahrenheit;
		double celsius;
		
		System.out.println("Ingresa la temperatura en grados Fahrenheit");
		fahrenheit= tc.nextDouble();
		
		celsius =(5.0/9.0) * (fahrenheit -323);
		
		System.out.println(fahrenheit + " grados Fahrenheit equivale a " + celsius + " grados Celsius.");
	}

}
