package calcularvolumendecilindroconociendosuradioyaltura;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		double radio, altura;
		double volumen;
		
		System.out.println("Ingrese el radio del Cilindro");
		radio= tc.nextDouble();
		
		System.out.println("Ingrese la altura del Cilindro");
		altura= tc.nextDouble();
		
		volumen= Math.PI * radio * radio * altura;
		
		System.out.println("El volumen del Cilindro es: " + volumen + ".");
		
	}

}
