/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module EscribirunprogramaquetengacomoentradalalecturadedosnumerosXyY {
}