package escribirunprogramaquetengacomoentradalalecturadedosnumerosXyY;

import java.util.Scanner;

public class Operacionespares {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		int x, y;

		System.out.println("Ingrese el valor de X: ");
		x = tc.nextInt();

		System.out.println("Ingrese el valor de Y: ");
		y = tc.nextInt();

		if (x < 0 && y < 0) { // (-X, -Y)
		int resultado = x*x + y*y;
		System.out.println("(-X, -Y) - Suma de cuadrados: " + resultado);
		} 
		
		else if (x < 0) { // (-X, Y) 
		int resultado = y - x;
		System.out.println("(-X, Y) - Resta de Y y X: " + resultado);
		} 
		
		else if (y < 0) { // (X, -Y)
		if (y == 0) {
		System.out.println("(X, -Y) - ERROR: No se puede dividir entre cero.");
		} 
		
		else {
		double resultado = (double)x / y;
		System.out.println("(X, -Y) - División de X entre Y: " + resultado);
		} 
		}
		
		else { // (X, Y)
		if (x > y) {
		int resultado = x + y;
		System.out.println("(X, Y) - Suma de Y y X: " + resultado);
	    } 
		
		else 
	    {
	     double resultado = Math.sqrt(x);
		System.out.println("(X, Y) - Raíz cuadrada de X: " + resultado);
		            
	         }
	         
	      } 
	     
		}
		
		
	}

