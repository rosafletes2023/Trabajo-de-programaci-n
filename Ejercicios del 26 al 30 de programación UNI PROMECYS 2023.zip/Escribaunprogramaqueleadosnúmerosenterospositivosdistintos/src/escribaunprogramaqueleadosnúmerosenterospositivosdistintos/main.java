package escribaunprogramaqueleadosnúmerosenterospositivosdistintos;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		int num1, num2;

	   System.out.println("Ingrese el primer número entero positivo");
	   num1 = tc.nextInt();

	   System.out.println("Ingrese el segundo número entero positivo: ");
	   num2 = tc.nextInt();

	   int mayor, menor;
	   if (num1 > num2) {
	   mayor = num1;
	   menor = num2;
	   } 
	   else {
	   mayor = num2;
	   menor = num1;
		        }

	  int diferencia = mayor - menor;

      System.out.println("La diferencia entre el mayor y el menor es: " + diferencia);
		    
	}
		

		
		
	}


