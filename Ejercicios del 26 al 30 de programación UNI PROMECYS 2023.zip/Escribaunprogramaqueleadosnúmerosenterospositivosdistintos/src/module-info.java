/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module Escribaunprogramaqueleadosnúmerosenterospositivosdistintos {
}