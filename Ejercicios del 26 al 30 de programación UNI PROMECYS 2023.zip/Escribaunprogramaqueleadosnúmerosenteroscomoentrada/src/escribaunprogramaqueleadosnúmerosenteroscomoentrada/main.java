package escribaunprogramaqueleadosnúmerosenteroscomoentrada;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		int num1, num2;
		
		System.out.println("Introduza el primer número entero");
		num1= tc.nextInt();
		
		System.out.println("Introduza el segundo número entero");
		num2= tc.nextInt();
		
		if ((num1 > 0 && num2 < 0) || (num1 < 0 && num2 > 0)) 
		{
            System.out.println("Los números tienen signos opuestos.");
        } else {
            System.out.println("Los números no tienen signos opuestos.");
            
		
        }
		
		
	}

}
