/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module Escribaunprogramaqueleadosnúmerosenteroscomoentrada {
}