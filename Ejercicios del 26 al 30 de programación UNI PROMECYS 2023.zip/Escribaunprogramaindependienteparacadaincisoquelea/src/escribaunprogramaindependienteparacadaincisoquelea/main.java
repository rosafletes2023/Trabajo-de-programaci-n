package escribaunprogramaindependienteparacadaincisoquelea;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Scanner tc= new Scanner(System.in);
	String num;
	
    System.out.println("Ingrese los números: ");
    num = tc.nextLine();

	switch(num.length()) {
	case 2:
    System.out.println("El primer número es: " + num.charAt(0));
    System.out.println("El segundo número es: " + num.charAt(1));
    break;
		            
	case 3:
    System.out.println("El primer número es: " + num.charAt(0));
    System.out.println("El segundo número es: " + num.charAt(1));
    System.out.println("El tercer número es: " + num.charAt(2));
    break;
		            
	case 4:
    System.out.println("El primer número es: " + num.charAt(0));
    System.out.println("El segundo número es: " + num.charAt(1));
    System.out.println("El tercer número es: " + num.charAt(2));
    System.out.println("El cuarto número es: " + num.charAt(3));
    break;
		           
	default:
   System.out.println("Debe ingresar dos, tres o cuatro números.");
		       
   
		    }
		}

		
	}

