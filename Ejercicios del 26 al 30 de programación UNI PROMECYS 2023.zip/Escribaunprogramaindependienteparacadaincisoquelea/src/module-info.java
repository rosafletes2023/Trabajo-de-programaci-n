/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module Escribaunprogramaindependienteparacadaincisoquelea {
}