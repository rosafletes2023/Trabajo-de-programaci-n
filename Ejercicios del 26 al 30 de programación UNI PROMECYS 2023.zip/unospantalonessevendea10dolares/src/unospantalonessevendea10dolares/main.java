package unospantalonessevendea10dolares;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		int cantidad;
		
		System.out.println("Ingrese la cantidad de pantalones que haz comprado");
		cantidad= tc.nextInt();
		
		double costoTotal;
		if(cantidad>3)
		{
			costoTotal= cantidad* 10;
			
		}
		
		else 
		{
			costoTotal= cantidad* 12;
		}
		
		
		System.out.println("El costo total es: $" + costoTotal);
		
		
	}

}
