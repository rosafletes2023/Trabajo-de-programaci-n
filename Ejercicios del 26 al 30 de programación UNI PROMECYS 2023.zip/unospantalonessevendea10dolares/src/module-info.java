/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module unospantalonessevendea10dolares {
}