package obtenerelvalordelcosenodeunnúmerocualquiera;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
	
        double numero, coseno;
		
        System.out.print("Ingresa el número en radianes: ");
        numero = tc.nextDouble();

        // Calcula el coseno del número utilizando el método Math.cos()
        coseno = Math.cos(numero);

        System.out.println("El coseno de " + numero + " es: " + coseno);
		
		
	}

}
