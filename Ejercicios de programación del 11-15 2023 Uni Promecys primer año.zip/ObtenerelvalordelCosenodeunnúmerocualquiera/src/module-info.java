/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module ObtenerelvalordelCosenodeunnúmerocualquiera {
}