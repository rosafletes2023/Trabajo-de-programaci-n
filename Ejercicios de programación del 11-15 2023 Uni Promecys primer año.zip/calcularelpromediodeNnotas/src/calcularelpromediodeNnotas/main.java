package calcularelpromediodeNnotas;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 Scanner tc= new Scanner(System.in);
         int n;
		 double sum = 0;
		        
		 System.out.println("Ingrese la cantidad de notas: ");
		 n = tc.nextInt();
		        
		 double[] notas = new double[n];
		        
		 for (int i = 0; i < n; i++) {
		 System.out.println("Ingrese la nota " + (i+1) + ": ");
		 notas[i] = tc.nextDouble();
		 sum += notas[i];
		 }
		        
		 double promedio = sum / n;
		        
	     System.out.println("El promedio de las " + n + " notas ingresadas es: " + promedio);
		  
		
		
	}

}
