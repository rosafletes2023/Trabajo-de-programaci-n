/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module calcularelpromediodeNnotas {
}