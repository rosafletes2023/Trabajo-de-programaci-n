/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module ecuacionlineal {
}