package ecuacionlineal;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		double a, b;
		
		System.out.println("Ingrese el valor de a");
		a= tc.nextDouble();
		
		System.out.println("Ingrese el valor de b");
		b= tc.nextDouble();
		
		if (a == 0) {
        if (b == 0) {
        System.out.println("La ecuación tiene infinitas soluciones.");
        } else {
        System.out.println("La ecuación no tiene solución.");
        }
        
        } else {
        double x = -b / a;
        System.out.println("La solución de la ecuación " + a + "x + " + b + " = 0 es x = " + x);
        }
      
	}

}
