package convertirYyardasFpiesyIpulgasacentimetros;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		double yardas, pies, pulgadas;
		double centímetros;
		
		System.out.println("Ingrese la cantidad de yardas");
		yardas= tc.nextDouble();
		
		System.out.println("Ingrese la cantidad de pies");
		pies= tc.nextDouble();
		
		System.out.println("Ingrese la cantidad de pulgadas");
		pulgadas= tc.nextDouble();
		
		double totalPulgadas = (yardas * 36) + (pies * 12) + pulgadas;
        double centimetros = totalPulgadas * 2.54;
        
        System.out.println(yardas + " yardas, " + pies + " pies, y " + pulgadas + " pulgadas equivale a " + centimetros + " centímetros.");
    
	
     }

}
