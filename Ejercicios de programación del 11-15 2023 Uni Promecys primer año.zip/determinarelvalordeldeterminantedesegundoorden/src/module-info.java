/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module determinarelvalordeldeterminantedesegundoorden {
}