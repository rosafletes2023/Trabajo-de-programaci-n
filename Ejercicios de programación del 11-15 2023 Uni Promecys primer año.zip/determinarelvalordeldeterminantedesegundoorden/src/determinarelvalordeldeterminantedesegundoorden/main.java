package determinarelvalordeldeterminantedesegundoorden;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc = new Scanner(System.in);
        double[][] matriz = new double[2][2];
        
        System.out.println("Ingrese los valores de la matriz 2x2:");
        for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
        System.out.println("Ingrese el valor en la posición [" + i + "][" + j + "]: ");
        matriz[i][j] = tc.nextDouble();
        
        }
        }
        
        double determinante = (matriz[0][0] * matriz[1][1]) - (matriz[0][1] * matriz[1][0]);
        
        System.out.println("El determinante de la matriz es: " + determinante);
    
	
	}
		
		
			
		
	}


