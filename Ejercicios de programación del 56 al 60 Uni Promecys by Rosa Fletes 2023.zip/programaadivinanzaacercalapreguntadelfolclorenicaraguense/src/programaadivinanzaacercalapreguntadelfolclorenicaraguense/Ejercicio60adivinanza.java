package programaadivinanzaacercalapreguntadelfolclorenicaraguense;

import java.util.Scanner;

public class Ejercicio60adivinanza {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		        String[] respuestas = {"Masaya", "León", "Granada", "Managua"};
		        String respuestaCorrecta = "Masaya";
		        Scanner tc = new Scanner(System.in);
		        int intentos = 0;

		        System.out.println("¿Cuál es la capital del folclore nicaragüense? Tienes tres oportunidades.");

		        while (intentos < 3) {
		            System.out.println("Respuesta: ");
		            String respuesta = tc.nextLine();
		            intentos++;

		            for (int i = 0; i < respuestas.length; i++) {
		                if (respuesta.equalsIgnoreCase(respuestas[i])) {
		                    System.out.println("¡Correcto!");
		                    tc.close();
		                    return;
		                }
		            }

		            if (intentos < 3) {
		                System.out.println("Incorrecto. Intenta de nuevo.");
		            }
		        }

		        System.out.println("Agotaste tus oportunidades. La respuesta correcta es " + respuestaCorrecta + ".");
		        tc.close();
		
	}

}
