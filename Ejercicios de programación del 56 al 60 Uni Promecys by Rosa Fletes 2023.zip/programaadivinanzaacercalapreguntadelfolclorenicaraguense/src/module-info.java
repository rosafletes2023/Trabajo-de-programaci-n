/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module programaadivinanzaacercalapreguntadelfolclorenicaraguense {
}