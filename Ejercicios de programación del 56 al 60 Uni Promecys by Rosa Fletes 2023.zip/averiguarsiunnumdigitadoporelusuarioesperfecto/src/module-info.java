/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module averiguarsiunnumdigitadoporelusuarioesperfecto {
}