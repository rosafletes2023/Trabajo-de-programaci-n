package averiguarsiunnumdigitadoporelusuarioesperfecto;

import java.util.Scanner;

public class Ejercicio59 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
    Scanner tc = new Scanner(System.in);
    System.out.println("Ingresa un número: ");
	int numero = tc.nextInt();

	// Crear un arreglo con los divisores del número
    int[] divisores = new int[numero];
    int indice = 0;
    for (int i = 1; i < numero; i++) {
    if (numero % i == 0) {
    divisores[indice] = i;
    indice++;
    }
    }

     // Calcular la suma de los divisores del número
     int sumaDivisores = 0;
	 for (int i = 0; i < indice; i++) {
     sumaDivisores += divisores[i];
	 }

      // Verificar si el número es perfecto
      if (sumaDivisores == numero) {
      System.out.println(numero + " es un número perfecto.");
	 } else {
     System.out.println(numero + " no es un número perfecto.");
		        }
		
		
	}

}
