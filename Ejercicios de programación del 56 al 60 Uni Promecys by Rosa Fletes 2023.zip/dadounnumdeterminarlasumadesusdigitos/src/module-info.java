/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module dadounnumdeterminarlasumadesusdigitos {
}