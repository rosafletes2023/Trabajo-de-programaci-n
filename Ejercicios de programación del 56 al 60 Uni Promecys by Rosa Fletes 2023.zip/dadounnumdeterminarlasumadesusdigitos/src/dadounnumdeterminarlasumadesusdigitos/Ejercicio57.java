package dadounnumdeterminarlasumadesusdigitos;

public class Ejercicio57 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
    int numero = 123456;
    int[] digitos = new int[6];
    int suma = 0;
    
    // Convertir el número en un arreglo de dígitos
    for (int i = 0; i < digitos.length; i++)
    {
    digitos[i] = numero % 10;
    numero /= 10;
    }

    // Sumar los dígitos
    for (int i = 0; i < digitos.length; i++) {
    suma += digitos[i];
    }

   // Imprimir la suma de los dígitos
   System.out.println("La suma de los dígitos de " + numero + " es " + suma);
		

	}

}
