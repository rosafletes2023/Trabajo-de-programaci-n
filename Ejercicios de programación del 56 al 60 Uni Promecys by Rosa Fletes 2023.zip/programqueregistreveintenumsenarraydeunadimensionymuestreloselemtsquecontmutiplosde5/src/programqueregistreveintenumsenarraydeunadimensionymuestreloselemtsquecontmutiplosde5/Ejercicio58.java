package programqueregistreveintenumsenarraydeunadimensionymuestreloselemtsquecontmutiplosde5;

public class Ejercicio58 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] numeros = {5, 12, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100};

	 // Buscar los números múltiplos de 5 y mostrarlos
     System.out.println("Números múltiplos de 5:");
     for (int i = 0; i < numeros.length; i++) {
    if (numeros[i] % 5 == 0) {
    System.out.println(numeros[i] + " ");
		          
                
		    }
		}

	     
		
		
		
		
		
		
	}

}
