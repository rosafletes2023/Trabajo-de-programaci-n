/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module programqueregistreveintenumsenarraydeunadimensionymuestreloselemtsquecontmutiplosde5 {
}