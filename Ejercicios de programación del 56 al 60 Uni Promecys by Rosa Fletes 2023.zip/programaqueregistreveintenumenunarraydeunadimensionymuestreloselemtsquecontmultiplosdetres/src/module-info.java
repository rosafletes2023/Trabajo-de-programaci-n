/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module programaqueregistreveintenumenunarraydeunadimensionymuestreloselemtsquecontmultiplosdetres {
}