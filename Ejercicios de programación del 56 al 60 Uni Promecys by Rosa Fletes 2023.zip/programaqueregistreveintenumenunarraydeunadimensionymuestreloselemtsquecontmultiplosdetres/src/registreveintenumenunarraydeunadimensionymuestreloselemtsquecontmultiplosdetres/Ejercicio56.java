package registreveintenumenunarraydeunadimensionymuestreloselemtsquecontmultiplosdetres;

public class Ejercicio56 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
     int[] numeros = new int[20];

      // Llenar el arreglo con números aleatorios
	 for (int i = 0; i < numeros.length; i++) {
     numeros[i] = (int)(Math.random() * 100);
		        }

      // Imprimir los elementos que contienen números múltiplos de 3
	   System.out.println("Elementos con números múltiplos de 3: ");
	   for (int i = 0; i < numeros.length; i++) {
       if (numeros[i] % 3 == 0) {
       System.out.println(numeros[i] + " ");
		           
       }
		
	   }
		
		
	}

}
