package EvaluarlafunciondeYparaelvalordeX;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double X=1;
	    double Y=5*Math.pow(X,4) + 2*Math.pow(X,3) + 3*Math.pow(X,2) + 7;
		
		System.out.println("Para X=" + X + ", Y=" + Y);
		
		// ahora, considerando un valor aleatorio de X:
        X= 3.5;
        Y = 5*Math.pow(X,4) + 2*Math.pow(X,3) + 3*Math.pow(X,2) + 7;
        System.out.println("Para X=" + X + ", Y=" + Y);
    
		
	}

}
