package perimetrodeunacircunferenciayareadeuncirculo;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		int radio; 
		double perimetro, area;
		double pi= 3.1416;
		
		System.out.println("Ingrese el radio a calcular");
		radio=tc.nextInt();
		
		perimetro= 2*pi*radio;
		area= pi*radio*radio;
		
		System.out.println("El perimetro es: " + perimetro + ".");
		System.out.println("El area es: " + area + ".");
		
		
		
		
		
		
	}

}
