/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module perimetrodeunacircunferenciayareadeuncirculo {
}