/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module areadeunrectangulo {
}