package areadeunrectangulo;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		
		int altura, base, radio;
		
		System.out.println("Ingrese la altura");
		altura= tc.nextInt();
		
		System.out.println("Ingrese la base");
		base= tc.nextInt();
		
		radio= altura*base;
		System.out.println("El area del rectángulo es: " + radio);
		
		
	}

}
