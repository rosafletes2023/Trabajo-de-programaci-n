package raizcuadradadeunnumerocualquiera;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc= new Scanner(System.in);
		double numero, raiz;
		
		System.out.println("Ingrese el número a obtener la raiz cuadrada");
		numero= tc.nextDouble();
		raiz= Math.sqrt(numero);
		
		System.out.println("La raiz cuadrada de "+numero+" es "+raiz);
		
		
	}

}
