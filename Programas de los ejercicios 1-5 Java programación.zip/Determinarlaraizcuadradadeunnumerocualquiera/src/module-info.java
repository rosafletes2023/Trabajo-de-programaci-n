/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module Determinarlaraizcuadradadeunnumerocualquiera {
}