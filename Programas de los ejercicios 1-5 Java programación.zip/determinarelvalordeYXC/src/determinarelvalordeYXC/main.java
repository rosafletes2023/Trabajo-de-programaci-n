package determinarelvalordeYXC;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double X= 2, C=2.5, Y= X*C-2;
		System.out.println("Para X=" + X + " y C=" + C + ", Y=" + Y);
	
		
		//ahora considerando un valor aleatorio
		
		X= 3.7;
		Y= X*C-2;
		System.out.println("Para X=" + X + " y C=" + C + ", Y=" + Y);
		
	}

}
